package com.upgrad.patterns.Middleware;

import com.upgrad.patterns.Authentication.AuthenticationProvider;
import com.upgrad.patterns.Authentication.JwtAuthProvider;

/**
 * Chain of Responsibility handler that processes JwtAuthProvider instances.
 */
public class JwtAuthProcessor extends AuthenticationProcessor {

    public JwtAuthProcessor(AuthenticationProcessor nextProcessor) {
        super(nextProcessor);
    }

    @Override
    public boolean isAuthorised(AuthenticationProvider provider) {
        if (provider instanceof JwtAuthProvider) {
            return provider.Authenticate();
        }
        if (nextProcessor != null) {
            return nextProcessor.isAuthorised(provider);
        }
        return false;
    }
}
