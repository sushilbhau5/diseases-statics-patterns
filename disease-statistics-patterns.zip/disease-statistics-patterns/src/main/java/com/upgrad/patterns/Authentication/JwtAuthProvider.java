package com.upgrad.patterns.Authentication;

/**
 * Authentication provider for JWT Bearer token authentication.
 */
public class JwtAuthProvider extends AuthenticationProvider {

    private static final String VALID_TOKEN = "upgrad";

    private final String token;

    public JwtAuthProvider(String token) {
        this.token = token;
    }

    @Override
    public boolean Authenticate() {
        if (token == null) {
            return false;
        }
        String normalized = token.startsWith("Bearer ") ? token.substring("Bearer ".length()).trim() : token.trim();
        return VALID_TOKEN.equals(normalized);
    }
}
