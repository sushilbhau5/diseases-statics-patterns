package com.upgrad.patterns.Strategies;

import com.upgrad.patterns.Entity.JohnHopkinResponse;
import com.upgrad.patterns.config.RestServiceGenerator;
import com.upgrad.patterns.interfaces.IndianDiseaseStat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

/**
 * Adapter implementation for retrieving Indian disease statistics from the John Hopkins dataset.
 */
@Service
public class JohnHopkinsStrategy implements IndianDiseaseStat {

    private static final Logger logger = LoggerFactory.getLogger(JohnHopkinsStrategy.class);
    private static final String TARGET_COUNTRY = "India";

    private final RestTemplate restTemplate;

    @Value("${config.johnHopkins-file:JohnHopkins.json}")
    private String johnHopkinsFile;

    public JohnHopkinsStrategy() {
        this.restTemplate = RestServiceGenerator.GetInstance();
    }

    @Override
    public Integer GetActiveCount() {
        try {
            JohnHopkinResponse[] responses = getJohnHopkinResponses();
            if (responses == null) {
                return 0;
            }
            return Arrays.stream(responses)
                    .filter(entry -> entry != null
                            && TARGET_COUNTRY.equalsIgnoreCase(entry.getCountry())
                            && entry.getStats() != null
                            && entry.getStats().getConfirmed() != null)
                    .mapToInt(entry -> entry.getStats().getConfirmed())
                    .sum();
        } catch (Exception ex) {
            logger.error("Error fetching John Hopkins count", ex);
            return 0;
        }
    }

    /**
     * Loads and deserializes the John Hopkins JSON response array.
     */
    public JohnHopkinResponse[] getJohnHopkinResponses() {
        String resourceName = (johnHopkinsFile != null && !johnHopkinsFile.isBlank())
                ? johnHopkinsFile
                : "JohnHopkins.json";
        if (restTemplate == null) {
            throw new IllegalStateException("RestTemplate singleton not initialized");
        }
        return JsonResourceHelper.readJsonFromClasspath(resourceName, JohnHopkinResponse[].class);
    }
}
