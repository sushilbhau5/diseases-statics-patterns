package com.upgrad.patterns.Constants;

/**
 * Supported external data source types for retrieving disease statistics.
 */
public enum SourceType {
    DiseaseSh,
    JohnHopkins
}
