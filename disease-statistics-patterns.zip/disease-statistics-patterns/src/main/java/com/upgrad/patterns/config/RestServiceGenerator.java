package com.upgrad.patterns.config;

import org.springframework.web.client.RestTemplate;

/**
 * Singleton pattern implementation that provides a single shared RestTemplate instance.
 */
public class RestServiceGenerator {

    private static volatile RestTemplate restTemplate;

    private RestServiceGenerator() {
        // Private constructor prevents direct instantiation.
    }

    /**
     * Returns the single shared RestTemplate instance, creating it lazily on first access.
     */
    public static RestTemplate GetInstance() {
        if (restTemplate == null) {
            synchronized (RestServiceGenerator.class) {
                if (restTemplate == null) {
                    restTemplate = new RestTemplate();
                }
            }
        }
        return restTemplate;
    }
}
