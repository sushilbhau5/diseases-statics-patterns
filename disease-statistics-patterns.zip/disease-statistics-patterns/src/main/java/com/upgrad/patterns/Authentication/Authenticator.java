package com.upgrad.patterns.Authentication;

import com.upgrad.patterns.Middleware.AuthenticationProcessor;
import com.upgrad.patterns.Middleware.BasicAuthProcessor;
import com.upgrad.patterns.Middleware.JwtAuthProcessor;
import jakarta.servlet.http.HttpServletRequest;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Builds the authentication processor chain and resolves the AuthenticationProvider
 * from incoming HTTP request headers.
 */
public class Authenticator {

    private Authenticator() {
    }

    /**
     * Chains authentication handlers: tries JWT authentication first, then falls back to Basic authentication.
     */
    public static AuthenticationProcessor GetAuthProcessor() {
        AuthenticationProcessor basicAuthProcessor = new BasicAuthProcessor(null);
        return new JwtAuthProcessor(basicAuthProcessor);
    }

    /**
     * Extracts credentials from the HTTP request and returns the matching AuthenticationProvider.
     */
    public static AuthenticationProvider GetAuthProvider(HttpServletRequest request) {
        if (request == null) {
            return null;
        }

        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && !authHeader.isBlank()) {
            if (authHeader.regionMatches(true, 0, "Bearer ", 0, 7)) {
                return new JwtAuthProvider(authHeader.substring(7).trim());
            }
            if (authHeader.regionMatches(true, 0, "Basic ", 0, 6)) {
                try {
                    String base64Credentials = authHeader.substring(6).trim();
                    byte[] decodedBytes = Base64.getDecoder().decode(base64Credentials);
                    String decoded = new String(decodedBytes, StandardCharsets.UTF_8);
                    int separatorIndex = decoded.indexOf(':');
                    if (separatorIndex > 0) {
                        String username = decoded.substring(0, separatorIndex);
                        String password = decoded.substring(separatorIndex + 1);
                        return new BasicAuthProvider(username, password);
                    }
                } catch (IllegalArgumentException ignored) {
                    return null;
                }
            }
        }

        String username = request.getHeader("username");
        String password = request.getHeader("password");
        if (username != null && password != null) {
            return new BasicAuthProvider(username, password);
        }

        return null;
    }
}
