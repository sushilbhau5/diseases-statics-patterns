package com.upgrad.patterns.Authentication;

/**
 * Abstract base class representing an authentication provider holding user credentials or tokens.
 */
public abstract class AuthenticationProvider {

    /**
     * Validates the credentials or token encapsulated by this provider.
     */
    public abstract boolean Authenticate();
}
