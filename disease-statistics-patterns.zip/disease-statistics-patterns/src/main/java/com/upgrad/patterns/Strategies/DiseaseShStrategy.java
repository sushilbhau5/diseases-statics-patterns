package com.upgrad.patterns.Strategies;

import com.upgrad.patterns.Entity.DiseaseShResponse;
import com.upgrad.patterns.config.RestServiceGenerator;
import com.upgrad.patterns.interfaces.IndianDiseaseStat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Adapter implementation for retrieving Indian disease statistics from the Disease.sh / Disease.io dataset.
 */
@Service
public class DiseaseShStrategy implements IndianDiseaseStat {

    private static final Logger logger = LoggerFactory.getLogger(DiseaseShStrategy.class);

    private final RestTemplate restTemplate;

    @Value("${config.diseaseSh-file:DiseaseSh.json}")
    private String diseaseShFile;

    public DiseaseShStrategy() {
        this.restTemplate = RestServiceGenerator.GetInstance();
    }

    @Override
    public Integer GetActiveCount() {
        try {
            DiseaseShResponse response = getDiseaseShResponseResponses();
            if (response == null || response.getCases() == null) {
                return 0;
            }
            return response.getCases();
        } catch (Exception ex) {
            logger.error("Error fetching Disease.sh count", ex);
            return 0;
        }
    }

    /**
     * Loads and deserializes the Disease.sh JSON response.
     * Uses the local JSON resource provided in the project (and retains the singleton RestTemplate).
     */
    public DiseaseShResponse getDiseaseShResponseResponses() {
        String resourceName = (diseaseShFile != null && !diseaseShFile.isBlank())
                ? diseaseShFile
                : "DiseaseSh.json";
        // Retain reference to singleton RestTemplate for external HTTP integration when configured.
        if (restTemplate == null) {
            throw new IllegalStateException("RestTemplate singleton not initialized");
        }
        return JsonResourceHelper.readJsonFromClasspath(resourceName, DiseaseShResponse.class);
    }
}
