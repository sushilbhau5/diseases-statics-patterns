package com.upgrad.patterns.Middleware;

import com.upgrad.patterns.Authentication.AuthenticationProvider;

/**
 * Abstract handler in the Chain of Responsibility authentication pipeline.
 */
public abstract class AuthenticationProcessor {

    public AuthenticationProcessor nextProcessor;

    public AuthenticationProcessor(AuthenticationProcessor nextProcessor) {
        this.nextProcessor = nextProcessor;
    }

    /**
     * Attempts to authorize the given AuthenticationProvider or delegates to the next processor.
     */
    public abstract boolean isAuthorised(AuthenticationProvider provider);
}
