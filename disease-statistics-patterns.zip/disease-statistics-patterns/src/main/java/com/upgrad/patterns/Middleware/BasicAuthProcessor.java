package com.upgrad.patterns.Middleware;

import com.upgrad.patterns.Authentication.AuthenticationProvider;
import com.upgrad.patterns.Authentication.BasicAuthProvider;

/**
 * Chain of Responsibility handler that processes BasicAuthProvider instances.
 */
public class BasicAuthProcessor extends AuthenticationProcessor {

    public BasicAuthProcessor(AuthenticationProcessor nextProcessor) {
        super(nextProcessor);
    }

    @Override
    public boolean isAuthorised(AuthenticationProvider provider) {
        if (provider instanceof BasicAuthProvider) {
            return provider.Authenticate();
        }
        if (nextProcessor != null) {
            return nextProcessor.isAuthorised(provider);
        }
        return false;
    }
}
