package com.upgrad.patterns.Authentication;

/**
 * Authentication provider for HTTP Basic (username/password) authentication.
 */
public class BasicAuthProvider extends AuthenticationProvider {

    private static final String VALID_USERNAME = "upgrad";
    private static final String VALID_PASSWORD = "password";

    private final String userName;
    private final String password;

    public BasicAuthProvider(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    @Override
    public boolean Authenticate() {
        return VALID_USERNAME.equals(userName) && VALID_PASSWORD.equals(password);
    }
}
