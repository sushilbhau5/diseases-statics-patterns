package com.upgrad.patterns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Disease Statistics Spring Boot application.
 */
@SpringBootApplication
public class DiseaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiseaseApplication.class, args);
    }
}
