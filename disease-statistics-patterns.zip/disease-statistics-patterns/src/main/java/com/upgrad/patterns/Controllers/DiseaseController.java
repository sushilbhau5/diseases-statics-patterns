package com.upgrad.patterns.Controllers;

import com.upgrad.patterns.Constants.SourceType;
import com.upgrad.patterns.Service.DiseaseCountFacade;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller exposing disease statistics endpoints via the DiseaseCountFacade.
 */
@RestController
@RequestMapping("/v1/disease")
public class DiseaseController {

    private final DiseaseCountFacade diseaseCountFacade;

    public DiseaseController(DiseaseCountFacade diseaseCountFacade) {
        this.diseaseCountFacade = diseaseCountFacade;
    }

    /**
     * Returns the Indian disease count from Disease.sh / Disease.io.
     */
    @GetMapping("/disease-sh-io/count")
    public ResponseEntity<Object> GetDiseaseShCount() {
        return ResponseEntity.ok(diseaseCountFacade.getDiseaseShCount());
    }

    /**
     * Returns the Indian disease count from John Hopkins.
     */
    @GetMapping("/john-hopkins/count")
    public ResponseEntity<Object> GetJohnHopkinsCount() {
        return ResponseEntity.ok(diseaseCountFacade.getJohnHopkinCount());
    }

    /**
     * Returns the infected ratio for the specified data source.
     */
    @GetMapping("/infected-ratio")
    public ResponseEntity<Object> GetInfectedRatio(@RequestParam SourceType sourceType) {
        return ResponseEntity.ok(diseaseCountFacade.getInfectedRatio(sourceType));
    }
}
