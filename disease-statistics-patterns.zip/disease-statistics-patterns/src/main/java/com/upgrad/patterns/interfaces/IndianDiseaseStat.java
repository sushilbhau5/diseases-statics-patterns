package com.upgrad.patterns.interfaces;

/**
 * Adapter interface defining a unified contract to retrieve India's disease count
 * from different external data sources.
 */
public interface IndianDiseaseStat {

    /**
     * Returns the disease case count for India from the adapted data source.
     */
    Integer GetActiveCount();
}
