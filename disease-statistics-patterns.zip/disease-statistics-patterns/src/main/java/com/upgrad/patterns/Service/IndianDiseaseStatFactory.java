package com.upgrad.patterns.Service;

import com.upgrad.patterns.Constants.SourceType;
import com.upgrad.patterns.Strategies.DiseaseShStrategy;
import com.upgrad.patterns.Strategies.JohnHopkinsStrategy;
import com.upgrad.patterns.interfaces.IndianDiseaseStat;
import org.springframework.stereotype.Service;

/**
 * Factory pattern implementation that selects the appropriate IndianDiseaseStat strategy
 * at runtime based on the requested SourceType.
 */
@Service
public class IndianDiseaseStatFactory {

    private final DiseaseShStrategy diseaseShStrategy;
    private final JohnHopkinsStrategy johnHopkinsStrategy;

    public IndianDiseaseStatFactory(DiseaseShStrategy diseaseShStrategy,
                                    JohnHopkinsStrategy johnHopkinsStrategy) {
        this.diseaseShStrategy = diseaseShStrategy;
        this.johnHopkinsStrategy = johnHopkinsStrategy;
    }

    /**
     * Returns the strategy implementation corresponding to the given SourceType.
     */
    public IndianDiseaseStat GetInstance(SourceType type) {
        if (type == null) {
            throw new IllegalArgumentException("SourceType must not be null");
        }
        switch (type) {
            case DiseaseSh:
                return diseaseShStrategy;
            case JohnHopkins:
                return johnHopkinsStrategy;
            default:
                throw new IllegalArgumentException("Unsupported SourceType: " + type);
        }
    }
}
