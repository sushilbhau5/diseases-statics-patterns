package com.upgrad.patterns.Service;

import com.upgrad.patterns.Constants.SourceType;
import org.springframework.stereotype.Service;

/**
 * Facade pattern implementation that hides strategy selection and data aggregation
 * details from the REST controller.
 */
@Service
public class DiseaseCountFacade {

    private static final double INDIA_POPULATION = 1_380_004_385.0;

    private final IndianDiseaseStatFactory indianDiseaseStatFactory;

    public DiseaseCountFacade(IndianDiseaseStatFactory indianDiseaseStatFactory) {
        this.indianDiseaseStatFactory = indianDiseaseStatFactory;
    }

    /**
     * Returns the disease case count from the Disease.sh / Disease.io source.
     */
    public Object getDiseaseShCount() {
        return indianDiseaseStatFactory.GetInstance(SourceType.DiseaseSh).GetActiveCount();
    }

    /**
     * Returns the disease case count from the John Hopkins source.
     */
    public Object getJohnHopkinCount() {
        return indianDiseaseStatFactory.GetInstance(SourceType.JohnHopkins).GetActiveCount();
    }

    /**
     * Calculates the infected ratio (percentage of India's population) for the specified source.
     */
    public Object getInfectedRatio(SourceType sourceType) {
        Integer activeCount = indianDiseaseStatFactory.GetInstance(sourceType).GetActiveCount();
        if (activeCount == null) {
            return 0.0;
        }
        double percentage = (activeCount / INDIA_POPULATION) * 100.0;
        return Math.round(percentage * 10000.0) / 10000.0;
    }
}
