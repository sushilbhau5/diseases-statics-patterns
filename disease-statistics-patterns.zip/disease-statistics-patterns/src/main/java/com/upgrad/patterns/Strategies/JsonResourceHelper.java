package com.upgrad.patterns.Strategies;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.InputStream;

/**
 * Shared helper for deserializing classpath JSON files used by disease strategies.
 */
final class JsonResourceHelper {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private JsonResourceHelper() {
    }

    static <T> T readJsonFromClasspath(String resourcePath, Class<T> targetType) {
        ClassPathResource resource = new ClassPathResource(resourcePath);
        try (InputStream inputStream = resource.getInputStream()) {
            return OBJECT_MAPPER.readValue(inputStream, targetType);
        } catch (IOException ex) {
            throw new IllegalStateException("Failed to read JSON resource: " + resourcePath, ex);
        }
    }
}
