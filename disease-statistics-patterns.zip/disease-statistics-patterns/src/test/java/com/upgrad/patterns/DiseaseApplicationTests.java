package com.upgrad.patterns;

import com.upgrad.patterns.Authentication.Authenticator;
import com.upgrad.patterns.Authentication.BasicAuthProvider;
import com.upgrad.patterns.Authentication.JwtAuthProvider;
import com.upgrad.patterns.Constants.SourceType;
import com.upgrad.patterns.Middleware.AuthenticationProcessor;
import com.upgrad.patterns.Service.DiseaseCountFacade;
import com.upgrad.patterns.Service.IndianDiseaseStatFactory;
import com.upgrad.patterns.Strategies.DiseaseShStrategy;
import com.upgrad.patterns.Strategies.JohnHopkinsStrategy;
import com.upgrad.patterns.config.RestServiceGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class DiseaseApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private IndianDiseaseStatFactory factory;

    @Autowired
    private DiseaseCountFacade facade;

    @Test
    void testSingletonRestTemplate() {
        RestTemplate first = RestServiceGenerator.GetInstance();
        RestTemplate second = RestServiceGenerator.GetInstance();
        assertSame(first, second, "RestServiceGenerator.GetInstance() must return the same instance");
    }

    @Test
    void testFactoryReturnsExpectedStrategies() {
        assertInstanceOf(DiseaseShStrategy.class, factory.GetInstance(SourceType.DiseaseSh));
        assertInstanceOf(JohnHopkinsStrategy.class, factory.GetInstance(SourceType.JohnHopkins));
    }

    @Test
    void testFacadeCounts() {
        assertEquals(45035393, facade.getDiseaseShCount());
        assertEquals(24644418, facade.getJohnHopkinCount());
    }

    @Test
    void testChainOfResponsibilityAuthentication() {
        AuthenticationProcessor processor = Authenticator.GetAuthProcessor();
        assertTrue(processor.isAuthorised(new JwtAuthProvider("upgrad")));
        assertFalse(processor.isAuthorised(new JwtAuthProvider("invalid")));
        assertTrue(processor.isAuthorised(new BasicAuthProvider("upgrad", "password")));
        assertFalse(processor.isAuthorised(new BasicAuthProvider("upgrad", "wrong")));
    }

    @Test
    void testEndpointsWithAndWithoutAuth() throws Exception {
        mockMvc.perform(get("/v1/disease/disease-sh-io/count"))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(get("/v1/disease/disease-sh-io/count")
                        .header("Authorization", "Bearer upgrad"))
                .andExpect(status().isOk())
                .andExpect(content().string("45035393"));

        mockMvc.perform(get("/v1/disease/john-hopkins/count")
                        .header("Authorization", "Bearer upgrad"))
                .andExpect(status().isOk())
                .andExpect(content().string("24644418"));

        mockMvc.perform(get("/v1/disease/infected-ratio")
                        .param("sourceType", "DiseaseSh")
                        .header("Authorization", "Bearer upgrad"))
                .andExpect(status().isOk());
    }
}
