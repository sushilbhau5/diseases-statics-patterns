# Disease Statistics Application Using Design Patterns

Spring Boot project implementing five classic design patterns to serve Indian disease statistics from `DiseaseSh.json` and `JohnHopkins.json`.

## Implemented Design Patterns

1. **Singleton Pattern** — `com.upgrad.patterns.config.RestServiceGenerator`
   - `GetInstance()` creates and returns a single shared `RestTemplate` instance.
2. **Adapter Pattern** — `com.upgrad.patterns.interfaces.IndianDiseaseStat`, `DiseaseShStrategy`, `JohnHopkinsStrategy`
   - Adapts two different JSON schemas (`DiseaseSh.json` and `JohnHopkins.json`) into a common `GetActiveCount()` interface.
3. **Factory Pattern** — `com.upgrad.patterns.Service.IndianDiseaseStatFactory`
   - `GetInstance(SourceType)` returns the requested strategy at runtime (`DiseaseSh` or `JohnHopkins`).
4. **Facade Pattern** — `com.upgrad.patterns.Service.DiseaseCountFacade`
   - `getDiseaseShCount()`, `getJohnHopkinCount()`, and `getInfectedRatio(SourceType)` shield `DiseaseController` from strategy and factory details.
5. **Chain of Responsibility Pattern** — `AuthenticationProcessor`, `JwtAuthProcessor`, `BasicAuthProcessor`, `Authenticator`, `AuthFilter`
   - `Authenticator.GetAuthProcessor()` chains `JwtAuthProcessor` -> `BasicAuthProcessor`.
   - Valid Bearer token: `Bearer upgrad`
   - Valid Basic credentials: username `upgrad`, password `password`

## How to Run (Step-by-Step for Beginners)

1. Install **IntelliJ IDEA Community Edition** (free) from JetBrains.
2. Open IntelliJ IDEA -> **Open** -> select this project folder (`disease-statistics-patterns`).
3. If IntelliJ asks to configure a Project SDK / JDK, click **Download JDK** and choose **Java 17** (Eclipse Temurin or Amazon Corretto).
4. Wait for IntelliJ to finish importing Maven dependencies.
5. Run the app:
   - Open `src/main/java/com/upgrad/patterns/DiseaseApplication.java` and click the green **Run** triangle next to `main`, **or**
   - Open the **Maven** tab on the right -> **Plugins** -> **spring-boot** -> double-click **spring-boot:run** (or run `mvn spring-boot:run` if Maven is installed in your terminal).
6. Test in **Postman**:
   - Open Postman -> **File -> Import** -> choose `postman_collection.json` from this folder.
   - Run all three requests:
     - `GET http://localhost:8080/v1/disease/disease-sh-io/count`
     - `GET http://localhost:8080/v1/disease/john-hopkins/count`
     - `GET http://localhost:8080/v1/disease/infected-ratio?sourceType=DiseaseSh`
