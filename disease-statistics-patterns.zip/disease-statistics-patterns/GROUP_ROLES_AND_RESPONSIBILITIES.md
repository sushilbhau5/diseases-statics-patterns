# Group Roles and Responsibilities

**Program:** UAM upGrad  
**Project:** Disease Statistics Application Using Design Patterns  

## Member Details

| Member Name | Program / Cohort | Responsibilities |
|---|---|---|
| Sushil Kumar Bhau | UAM upGrad | Project setup, Singleton (`RestServiceGenerator`), Adapter (`IndianDiseaseStat`, `DiseaseShStrategy`, `JohnHopkinsStrategy`), Factory (`IndianDiseaseStatFactory`), Facade (`DiseaseCountFacade`), Chain of Responsibility (`Authenticator`, `AuthFilter`, `JwtAuthProcessor`, `BasicAuthProcessor`), REST API (`DiseaseController`), Postman testing, and documentation |

*(If working in a group, add your teammates' names and split the rows above before submitting.)*
